export default function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50">
      {/* Header / Hero */}
      <header className="relative overflow-hidden bg-gradient-to-r from-slate-900 to-slate-800 text-white">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute -top-24 -right-24 h-96 w-96 rounded-full bg-blue-400 blur-3xl" />
          <div className="absolute -bottom-24 -left-24 h-96 w-96 rounded-full bg-indigo-400 blur-3xl" />
        </div>
        <div className="relative mx-auto max-w-5xl px-6 py-16 sm:py-20">
          <div className="space-y-4">
            <h1 className="text-4xl font-bold tracking-tight sm:text-5xl">
              Christian Anita Omenogor
            </h1>
            <div className="flex flex-wrap gap-4 text-sm text-slate-300">
              <span className="inline-flex items-center gap-1.5">
                <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                </svg>
                anichristian63@gmail.com
              </span>
              <span className="inline-flex items-center gap-1.5">
                <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                </svg>
                +234 904 302 5544
              </span>
              <span className="inline-flex items-center gap-1.5">
                <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                  <path strokeLinecap="round" strokeLinejoin="round" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                </svg>
                Remote Only
              </span>
            </div>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-5xl px-6 py-10 space-y-10">
        {/* Target Role */}
        <section>
          <h2 className="mb-3 text-xs font-semibold uppercase tracking-widest text-blue-600">
            Target Role
          </h2>
          <p className="text-lg font-medium text-slate-800">
            Virtual Assistant (Remote) | Administrative Assistant | Scheduling Coordinator
          </p>
        </section>

        {/* Professional Summary */}
        <section>
          <h2 className="mb-4 text-xs font-semibold uppercase tracking-widest text-blue-600">
            Professional Summary
          </h2>
          <div className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
            <p className="leading-relaxed text-slate-700">
              Detail-oriented administrative and customer support professional with experience managing
              phone/email communication, scheduling, documentation, and record-keeping. Comfortable
              supporting remote teams using Google Workspace, Microsoft Office, Slack, Notion, and CRM
              tools (Zoho). Known for professionalism, organization, responsiveness, and a
              customer-first mindset.
            </p>
          </div>
        </section>

        {/* Core Skills */}
        <section>
          <h2 className="mb-4 text-xs font-semibold uppercase tracking-widest text-blue-600">
            Core Skills
          </h2>
          <div className="flex flex-wrap gap-2">
            {[
              "Scheduling & Coordination",
              "Email & Phone Communication",
              "Documentation & Data Entry",
              "Task Tracking (Notion)",
              "Customer Service",
              "Record Management",
              "Time Management",
              "Remote Collaboration",
            ].map((skill) => (
              <span
                key={skill}
                className="rounded-full bg-blue-50 px-4 py-1.5 text-sm font-medium text-blue-700 ring-1 ring-blue-200/50"
              >
                {skill}
              </span>
            ))}
          </div>
        </section>

        {/* Tools */}
        <section>
          <h2 className="mb-4 text-xs font-semibold uppercase tracking-widest text-blue-600">
            Tools
          </h2>
          <div className="flex flex-wrap gap-2">
            {[
              "Google Workspace",
              "Microsoft Office",
              "Slack",
              "Notion",
              "Zoho CRM",
            ].map((tool) => (
              <span
                key={tool}
                className="rounded-full bg-indigo-50 px-4 py-1.5 text-sm font-medium text-indigo-700 ring-1 ring-indigo-200/50"
              >
                {tool}
              </span>
            ))}
          </div>
        </section>

        {/* Professional Experience */}
        <section>
          <h2 className="mb-6 text-xs font-semibold uppercase tracking-widest text-blue-600">
            Professional Experience
          </h2>
          <div className="space-y-6">
            {/* BUYPOWER */}
            <div className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
              <div className="flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between">
                <h3 className="text-lg font-semibold text-slate-900">BUYPOWER</h3>
                <span className="text-sm text-slate-500">Jan 2025 – Present</span>
              </div>
              <p className="mb-3 text-sm font-medium text-slate-600">
                Customer Support / Telesales Representative
              </p>
              <ul className="space-y-2 text-sm text-slate-700">
                <li className="flex items-start gap-2">
                  <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-blue-500" />
                  Managed high-volume customer communication by phone; captured accurate details and next steps for follow-up.
                </li>
                <li className="flex items-start gap-2">
                  <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-blue-500" />
                  Maintained organized customer records in Zoho CRM; ensured clean documentation for service continuity.
                </li>
                <li className="flex items-start gap-2">
                  <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-blue-500" />
                  Coordinated with internal teams to route issues and support timely resolution.
                </li>
              </ul>
            </div>

            {/* MACHIBES TECHNOLOGY */}
            <div className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
              <div className="flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between">
                <h3 className="text-lg font-semibold text-slate-900">MACHIBES TECHNOLOGY</h3>
                <span className="text-sm text-slate-500">May 2024 – Dec 2024</span>
              </div>
              <p className="mb-3 text-sm font-medium text-slate-600">
                Front Desk Personnel
              </p>
              <ul className="space-y-2 text-sm text-slate-700">
                <li className="flex items-start gap-2">
                  <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-blue-500" />
                  Managed appointment scheduling and visitor coordination; supported smooth day-to-day operations.
                </li>
                <li className="flex items-start gap-2">
                  <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-blue-500" />
                  Responded to inquiries via phone and email; provided timely, professional communication.
                </li>
                <li className="flex items-start gap-2">
                  <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-blue-500" />
                  Maintained administrative records and documentation with strong attention to detail.
                </li>
              </ul>
            </div>
          </div>
        </section>

        {/* Education */}
        <section>
          <h2 className="mb-4 text-xs font-semibold uppercase tracking-widest text-blue-600">
            Education
          </h2>
          <div className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
            <h3 className="font-semibold text-slate-900">Federal Polytechnic Idah, Kogi State</h3>
            <p className="text-sm text-slate-600">HND, Public Administration (Distinction)</p>
          </div>
        </section>

        {/* Certifications */}
        <section>
          <h2 className="mb-4 text-xs font-semibold uppercase tracking-widest text-blue-600">
            Certifications
          </h2>
          <div className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
            <ul className="space-y-2 text-sm text-slate-700">
              <li className="flex items-start gap-2">
                <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-indigo-500" />
                ALX Virtual Assistant Training (8 weeks)
              </li>
              <li className="flex items-start gap-2">
                <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-indigo-500" />
                Professional in Human Resource International (PHRi)
              </li>
            </ul>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-white">
        <div className="mx-auto max-w-5xl px-6 py-6 text-center text-sm text-slate-500">
          &copy; {new Date().getFullYear()} Christian Anita Omenogor &middot; Available for Remote Virtual Assistant roles
        </div>
      </footer>
    </div>
  );
}
